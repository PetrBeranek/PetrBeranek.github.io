var searchData=
[
  ['name',['name',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#a8f3b09dba2844edd6cc637206656050f',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['nattribspervertex',['nAttribsPerVertex',['../structpgr_1_1_mesh_data.html#a123988fb84ed25ef5df2b93470fea682',1,'pgr::MeshData']]],
  ['nindices',['nIndices',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#ad68d429fc84e651d06df7b279421cc15',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['ntriangles',['nTriangles',['../structpgr_1_1_mesh_data.html#a404e695de153d6984506da2ca1847522',1,'pgr::MeshData']]],
  ['nvertices',['nVertices',['../structpgr_1_1_mesh_data.html#a80438369cba659be2aab1330a33af3f9',1,'pgr::MeshData']]]
];
