var searchData=
[
  ['basevertex',['baseVertex',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#ab2fe1e8f8ff80fb4cfabdc28ed1dec60',1,'pgr::sg::MeshGeometry::SubMesh']]]
];
