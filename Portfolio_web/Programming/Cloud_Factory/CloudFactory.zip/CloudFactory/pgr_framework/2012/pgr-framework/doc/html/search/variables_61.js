var searchData=
[
  ['ambient',['ambient',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#ab4892bd84a1db96b9cfc41258012f3e9',1,'pgr::sg::MeshGeometry::SubMesh']]]
];
