var searchData=
[
  ['singleton_5fdecl',['SINGLETON_DECL',['../_resources_8h.html#af26982d0753c9ee64385cafb2ed62ae5',1,'Resources.h']]],
  ['singleton_5fdef',['SINGLETON_DEF',['../_resources_8h.html#a7a3881a322265978ca4fe11277fa47ab',1,'Resources.h']]]
];
