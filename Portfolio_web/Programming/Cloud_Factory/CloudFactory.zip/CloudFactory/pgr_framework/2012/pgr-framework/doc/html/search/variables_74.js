var searchData=
[
  ['teapotdata',['teapotData',['../namespacepgr.html#a96f24e8a514f6b90ae9a44781fde3a01',1,'pgr']]],
  ['textureid',['textureID',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#a85580273e05c8ccca8ccf4ac1b084cea',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['texturename',['textureName',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#a9624364965ca863e280069b36a498c84',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['triangles',['triangles',['../structpgr_1_1_mesh_data.html#aa85af423c2aee2be54d2f325c21e565b',1,'pgr::MeshData']]]
];
