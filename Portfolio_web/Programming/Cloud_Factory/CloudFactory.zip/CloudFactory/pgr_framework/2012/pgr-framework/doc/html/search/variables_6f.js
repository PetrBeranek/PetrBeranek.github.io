var searchData=
[
  ['ogl_5fver_5fmajor',['OGL_VER_MAJOR',['../namespacepgr.html#aecf0b0919c8615acf57d2f5e27ab1a5a',1,'pgr']]],
  ['ogl_5fver_5fminor',['OGL_VER_MINOR',['../namespacepgr.html#a8fc76d49c63bdec0c5b4dd39fd39e5c0',1,'pgr']]]
];
