var searchData=
[
  ['debuglevel',['DebugLevel',['../namespacepgr.html#a87caedf15ec69b9c64ee2f1e5cc5e887',1,'pgr']]]
];
