var searchData=
[
  ['shininess',['shininess',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#ab34591702d323c989aae7250c87d8f9b',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['specular',['specular',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#adb3f33258df7c0fb04ebf5217a682a89',1,'pgr::sg::MeshGeometry::SubMesh']]],
  ['startindex',['startIndex',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#a550ee309233c5f94cf46134befc6341d',1,'pgr::sg::MeshGeometry::SubMesh']]]
];
