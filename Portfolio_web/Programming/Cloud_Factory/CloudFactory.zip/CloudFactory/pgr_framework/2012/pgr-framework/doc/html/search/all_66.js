var searchData=
[
  ['frameworkroot',['frameworkRoot',['../namespacepgr.html#a81a9686443c308d87d07ba14868df160',1,'pgr']]]
];
