var searchData=
[
  ['diffuse',['diffuse',['../structpgr_1_1sg_1_1_mesh_geometry_1_1_sub_mesh.html#a31d012f8472ab367d4f7ade352db73d6',1,'pgr::sg::MeshGeometry::SubMesh']]]
];
